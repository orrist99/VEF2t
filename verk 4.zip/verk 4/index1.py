from bottle import route, run, template, static_file, error

@route('/')
def index():
    return template("index.tpl")

@route('/pic')
def pic():
    return template("index2.tpl")

@route('/bio')
def bio():
    return template("index3.tpl")
"""
verk2

"""


@route('/verk2')
def verk2():

    title=[["news"]]
    newshead=[["Sun burns eyes"]]
    newsmain=[["man burns eys when looking at sunset blablablabbalbblabladgskjfpsajdf kas snbdkfj hlsnfdvaosf nksjhotdisfndh sapjfsnogfha pxjdfnsdo igfjsfnjsdhfjss hfsfhsf"]]
    img=[['sun']]
    return template("verk2.tpl", newshead, newsmain, img)






@route('/static/<skra>')
def static_skrar(skra):
    return static_file(skra, root='./use/')


@error(404)
def error404(error):
    return template("error.tpl")

run(debug=True, port=8080 )